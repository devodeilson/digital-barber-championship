<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\ChampionshipController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\ContentController;
use App\Http\Controllers\Admin\ReportController;
use App\Http\Controllers\Admin\SettingController;

// Rotas de autenticação
Auth::routes();

// Rota principal
Route::get('/', function () {
    return view('welcome');
});

// Rotas do Admin
Route::prefix('admin')->middleware(['auth', 'admin'])->name('admin.')->group(function () {
    // Dashboard
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

    // Campeonatos
    Route::resource('championships', ChampionshipController::class);

    // Usuários
    Route::resource('users', UserController::class);

    // Conteúdos
    Route::resource('contents', ContentController::class);

    // Relatórios
    Route::get('reports', [ReportController::class, 'index'])->name('reports.index');
    Route::get('reports/users', [ReportController::class, 'users'])->name('reports.users');
    Route::get('reports/championships', [ReportController::class, 'championships'])->name('reports.championships');
    Route::get('reports/contents', [ReportController::class, 'contents'])->name('reports.contents');
    Route::get('reports/export/{type}', [ReportController::class, 'export'])->name('reports.export');

    // Configurações
    Route::get('settings', [SettingController::class, 'edit'])->name('settings');
    Route::put('settings', [SettingController::class, 'update'])->name('settings.update');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
