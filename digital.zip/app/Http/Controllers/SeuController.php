<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

class SeuController extends Controller
{
    // private $paymentGateway;

    public function __construct(/* PaymentGateway $paymentGateway */)
    {
        // $this->paymentGateway = $paymentGateway;
    }
}
