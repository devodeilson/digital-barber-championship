<?php

namespace App\Http\Controllers;

use App\Models\Championship;
use App\Models\Payment;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Services\PaymentGateway;
use App\Notifications\PaymentNotification;
use Illuminate\Support\Facades\Log;

class PaymentController extends Controller
{
    protected $paymentGateway;

    public function __construct(PaymentGateway $paymentGateway)
    {
        $this->paymentGateway = $paymentGateway;
    }

    public function checkout(Transaction $transaction)
    {
        try {
            if ($transaction->status !== 'pending') {
                return redirect()->route('championships.show', $transaction->championship)
                    ->with('error', 'Esta transação não está mais pendente.');
            }

            $payment = $this->paymentGateway->createPayment($transaction);

            return redirect($payment['url']);
        } catch (\Exception $e) {
            Log::error('Erro no checkout: ' . $e->getMessage(), [
                'transaction_id' => $transaction->id,
                'error' => $e->getMessage()
            ]);

            return redirect()->route('championships.show', $transaction->championship)
                ->with('error', 'Erro ao processar pagamento. Por favor, tente novamente.');
        }
    }

    public function success(Transaction $transaction)
    {
        try {
            $paymentInfo = $this->paymentGateway->getPaymentInfo($transaction->payment_id);

            if ($paymentInfo['status'] === 'succeeded') {
                $transaction->complete();

                return redirect()->route('championships.show', $transaction->championship)
                    ->with('success', 'Pagamento confirmado com sucesso!');
            }

            return redirect()->route('championships.show', $transaction->championship)
                ->with('info', 'Aguardando confirmação do pagamento...');
        } catch (\Exception $e) {
            Log::error('Erro na confirmação: ' . $e->getMessage(), [
                'transaction_id' => $transaction->id,
                'error' => $e->getMessage()
            ]);

            return redirect()->route('championships.show', $transaction->championship)
                ->with('error', 'Erro ao confirmar pagamento. Entre em contato com o suporte.');
        }
    }

    public function cancel(Transaction $transaction)
    {
        $transaction->fail('Cancelado pelo usuário');

        return redirect()->route('championships.show', $transaction->championship)
            ->with('info', 'Pagamento cancelado.');
    }

    public function webhook(Request $request)
    {
        try {
            // Verificar assinatura do webhook
            if (!$this->verifyWebhookSignature($request)) {
                return response()->json(['error' => 'Invalid signature'], 400);
            }

            $this->paymentGateway->handleWebhook($request->all());

            return response()->json(['status' => 'success']);
        } catch (\Exception $e) {
            Log::error('Erro no webhook: ' . $e->getMessage(), [
                'payload' => $request->all(),
                'error' => $e->getMessage()
            ]);

            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    protected function verifyWebhookSignature(Request $request)
    {
        $signature = $request->header('X-Payment-Signature');
        $payload = $request->getContent();
        $expectedSignature = hash_hmac('sha256', $payload, config('services.payment.webhook_secret'));

        return hash_equals($expectedSignature, $signature);
    }
} 