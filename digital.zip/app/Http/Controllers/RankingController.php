<?php

namespace App\Http\Controllers;

use App\Models\Ranking;
use App\Models\Championship;
use App\Models\Content;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RankingController extends Controller
{
    public function show(Championship $championship, $type = 'monthly')
    {
        $rankings = Ranking::where('championship_id', $championship->id)
            ->where('type', $type)
            ->with(['user:id,name,country,profile_photo'])
            ->orderBy('position')
            ->paginate(20);

        // Busca posição do usuário atual
        $userRanking = Ranking::where('championship_id', $championship->id)
            ->where('type', $type)
            ->where('user_id', auth()->id())
            ->first();

        return view('rankings.show', compact('championship', 'rankings', 'userRanking', 'type'));
    }

    public function updateStageRanking(Championship $championship, $stageNumber)
    {
        // Calcula ranking baseado nas médias dos conteúdos da etapa
        $results = Content::where('championship_id', $championship->id)
            ->where('stage_number', $stageNumber)
            ->where('status', 'approved')
            ->select('user_id', DB::raw('AVG(average_score) as points'))
            ->groupBy('user_id')
            ->orderByDesc('points')
            ->get();

        $position = 1;
        foreach ($results as $result) {
            Ranking::updateOrCreate(
                [
                    'championship_id' => $championship->id,
                    'user_id' => $result->user_id,
                    'type' => 'stage',
                    'stage_number' => $stageNumber
                ],
                [
                    'points' => $result->points,
                    'position' => $position,
                    'virtual_coins' => $this->calculateVirtualCoins($position)
                ]
            );
            $position++;
        }

        $this->updateMonthlyRanking($championship);
        return redirect()->back()->with('success', 'Rankings atualizados com sucesso!');
    }

    public function updateMonthlyRanking(Championship $championship)
    {
        // Calcula ranking mensal baseado na média das etapas
        $results = Ranking::where('championship_id', $championship->id)
            ->where('type', 'stage')
            ->select('user_id', DB::raw('AVG(points) as monthly_points'))
            ->groupBy('user_id')
            ->orderByDesc('monthly_points')
            ->get();

        $position = 1;
        foreach ($results as $result) {
            Ranking::updateOrCreate(
                [
                    'championship_id' => $championship->id,
                    'user_id' => $result->user_id,
                    'type' => 'monthly'
                ],
                [
                    'points' => $result->monthly_points,
                    'position' => $position,
                    'virtual_coins' => $this->calculateVirtualCoins($position)
                ]
            );
            $position++;
        }
    }

    public function getChampionshipRanking(Championship $championship, $type = 'monthly')
    {
        $rankings = Ranking::with('user:id,name,country')
            ->where('championship_id', $championship->id)
            ->where('type', $type)
            ->orderBy('position')
            ->get();

        return response()->json($rankings);
    }

    private function calculateVirtualCoins($position)
    {
        return match (true) {
            $position === 1 => 100,
            $position === 2 => 75,
            $position === 3 => 50,
            $position <= 10 => 25,
            default => 10
        };
    }
} 