<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Championship;
use App\Models\Content;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ReportController extends Controller
{
    public function index()
    {
        // Estatísticas gerais
        $stats = [
            'total_users' => User::count(),
            'total_championships' => Championship::count(),
            'total_contents' => Content::count(),
            'total_revenue' => Transaction::where('status', 'completed')->sum('amount')
        ];

        // Usuários por mês
        $usersPerMonth = User::select(
            DB::raw('DATE_FORMAT(created_at, "%Y-%m") as month'),
            DB::raw('COUNT(*) as count')
        )
            ->groupBy('month')
            ->orderBy('month', 'desc')
            ->limit(12)
            ->get();

        // Conteúdos por status
        $contentsByStatus = Content::select('status', DB::raw('COUNT(*) as count'))
            ->groupBy('status')
            ->get();

        // Campeonatos mais populares
        $popularChampionships = Championship::withCount('contents')
            ->orderBy('contents_count', 'desc')
            ->limit(5)
            ->get();

        // Receita por mês
        $revenuePerMonth = Transaction::select(
            DB::raw('DATE_FORMAT(created_at, "%Y-%m") as month'),
            DB::raw('SUM(amount) as total')
        )
            ->where('status', 'completed')
            ->groupBy('month')
            ->orderBy('month', 'desc')
            ->limit(12)
            ->get();

        return view('admin.reports.index', compact(
            'stats',
            'usersPerMonth',
            'contentsByStatus',
            'popularChampionships',
            'revenuePerMonth'
        ));
    }

    public function export(Request $request, $type)
    {
        $startDate = $request->input('start_date', Carbon::now()->subMonth());
        $endDate = $request->input('end_date', Carbon::now());

        switch ($type) {
            case 'users':
                return $this->exportUsers($startDate, $endDate);
            case 'championships':
                return $this->exportChampionships($startDate, $endDate);
            case 'contents':
                return $this->exportContents($startDate, $endDate);
            case 'transactions':
                return $this->exportTransactions($startDate, $endDate);
            default:
                return redirect()->back()->with('error', 'Tipo de relatório inválido.');
        }
    }

    private function exportUsers($startDate, $endDate)
    {
        $users = User::whereBetween('created_at', [$startDate, $endDate])
            ->get(['name', 'email', 'created_at']);

        // Lógica para exportar CSV
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename=users.csv',
        ];

        $callback = function() use ($users) {
            $file = fopen('php://output', 'w');
            fputcsv($file, ['Nome', 'Email', 'Data de Cadastro']);

            foreach ($users as $user) {
                fputcsv($file, [
                    $user->name,
                    $user->email,
                    $user->created_at->format('d/m/Y H:i:s')
                ]);
            }

            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }

    // Métodos similares para outros tipos de exportação...
}
