<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Championship;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ChampionshipController extends Controller
{
    public function index()
    {
        $championships = Championship::with('user')
            ->withCount('contents')
            ->latest()
            ->paginate(10);

        return view('admin.championships.index', compact('championships'));
    }

    public function create()
    {
        return view('admin.championships.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|max:255',
            'description' => 'required',
            'category' => 'required',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
            'prize' => 'required|numeric|min:0',
            'rules' => 'required',
            'image' => 'nullable|image|max:2048',
            'status' => 'required|in:active,inactive'
        ]);

        if ($request->hasFile('image')) {
            $validated['image'] = $request->file('image')->store('championships', 'public');
        }

        $validated['user_id'] = auth()->id();

        Championship::create($validated);

        return redirect()->route('admin.championships.index')
            ->with('success', 'Campeonato criado com sucesso!');
    }

    public function show(Championship $championship)
    {
        $championship->load(['user', 'contents.user']);
        return view('admin.championships.show', compact('championship'));
    }

    public function edit(Championship $championship)
    {
        return view('admin.championships.edit', compact('championship'));
    }

    public function update(Request $request, Championship $championship)
    {
        $validated = $request->validate([
            'name' => 'required|max:255',
            'description' => 'required',
            'category' => 'required',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
            'prize' => 'required|numeric|min:0',
            'rules' => 'required',
            'image' => 'nullable|image|max:2048',
            'status' => 'required|in:active,inactive'
        ]);

        if ($request->hasFile('image')) {
            if ($championship->image) {
                Storage::disk('public')->delete($championship->image);
            }
            $validated['image'] = $request->file('image')->store('championships', 'public');
        }

        $championship->update($validated);

        return redirect()->route('admin.championships.index')
            ->with('success', 'Campeonato atualizado com sucesso!');
    }

    public function destroy(Championship $championship)
    {
        if ($championship->image) {
            Storage::disk('public')->delete($championship->image);
        }

        $championship->delete();

        return redirect()->route('admin.championships.index')
            ->with('success', 'Campeonato excluído com sucesso!');
    }
}
