<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Vote extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'content_id',
        'rating',
        'comment'
    ];

    protected $casts = [
        'rating' => 'float'
    ];

    // Relacionamentos
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function content(): BelongsTo
    {
        return $this->belongsTo(Content::class);
    }

    // Boot
    protected static function boot()
    {
        parent::boot();

        // Após criar ou atualizar, recalcula a média do conteúdo
        static::saved(function ($vote) {
            $vote->content->updateRating();
        });

        // Após deletar, recalcula a média do conteúdo
        static::deleted(function ($vote) {
            $vote->content->updateRating();
        });
    }

    // Validações
    public static function rules()
    {
        return [
            'rating' => ['required', 'numeric', 'min:1', 'max:5'],
            'comment' => ['nullable', 'string', 'max:1000']
        ];
    }

    // Scopes
    public function scopeByUser($query, $userId)
    {
        return $query->where('user_id', $userId);
    }

    public function scopeByContent($query, $contentId)
    {
        return $query->where('content_id', $contentId);
    }

    public function scopeWithRating($query, $rating)
    {
        return $query->where('rating', $rating);
    }

    // Métodos
    public function canBeEditedBy(User $user)
    {
        return $this->user_id === $user->id &&
               $this->created_at->addHours(24)->isFuture();
    }
}
