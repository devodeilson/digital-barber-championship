<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Ranking extends Model
{
    protected $fillable = [
        'user_id',
        'championship_id',
        'stage_number',
        'points',
        'type', // stage, monthly, final, national
        'position',
        'virtual_coins'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function championship()
    {
        return $this->belongsTo(Championship::class);
    }
} 