<?php

namespace App\Services;

use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Image;
use Exception;

class StorageService
{
    protected $disk;

    public function __construct()
    {
        $this->disk = Storage::disk('s3');
    }

    public function uploadImage($file, $path = 'images', $resize = true)
    {
        try {
            if ($resize) {
                $image = Image::make($file);
                $image->resize(1200, null, function ($constraint) {
                    $constraint->aspectRatio();
                    $constraint->upsize();
                });
                
                $filename = Str::random(40) . '.' . $file->getClientOriginalExtension();
                $fullPath = $path . '/' . $filename;
                
                $this->disk->put($fullPath, $image->stream()->__toString(), 'public');
                
                return $fullPath;
            }

            $filename = Str::random(40) . '.' . $file->getClientOriginalExtension();
            $fullPath = $path . '/' . $filename;
            
            $this->disk->putFileAs($path, $file, $filename, 'public');
            
            return $fullPath;
        } catch (Exception $e) {
            \Log::error('Failed to upload image', [
                'error' => $e->getMessage(),
                'path' => $path
            ]);
            
            throw $e;
        }
    }

    public function uploadVideo($file, $path = 'videos')
    {
        try {
            $filename = Str::random(40) . '.' . $file->getClientOriginalExtension();
            $fullPath = $path . '/' . $filename;
            
            $this->disk->putFileAs($path, $file, $filename, 'public');
            
            return $fullPath;
        } catch (Exception $e) {
            \Log::error('Failed to upload video', [
                'error' => $e->getMessage(),
                'path' => $path
            ]);
            
            throw $e;
        }
    }

    public function delete($path)
    {
        try {
            if ($this->disk->exists($path)) {
                return $this->disk->delete($path);
            }
            return false;
        } catch (Exception $e) {
            \Log::error('Failed to delete file', [
                'error' => $e->getMessage(),
                'path' => $path
            ]);
            
            throw $e;
        }
    }

    public function getUrl($path)
    {
        try {
            return $this->disk->url($path);
        } catch (Exception $e) {
            \Log::error('Failed to get file URL', [
                'error' => $e->getMessage(),
                'path' => $path
            ]);
            
            throw $e;
        }
    }
} 