@extends('layouts.admin')

@section('content')
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3">Campeonatos</h1>
        <a href="{{ route('admin.championships.create') }}" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>Novo Campeonato
        </a>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Categoria</th>
                            <th>Início</th>
                            <th>Término</th>
                            <th>Prêmio</th>
                            <th>Participantes</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($championships as $championship)
                            <tr>
                                <td>{{ $championship->name }}</td>
                                <td>{{ $championship->category }}</td>
                                <td>{{ $championship->start_date->format('d/m/Y') }}</td>
                                <td>{{ $championship->end_date->format('d/m/Y') }}</td>
                                <td>R$ {{ number_format($championship->prize, 2, ',', '.') }}</td>
                                <td>{{ $championship->contents_count }}</td>
                                <td>
                                    <span class="badge bg-{{ $championship->status === 'active' ? 'success' : 'danger' }}">
                                        {{ $championship->status }}
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <a href="{{ route('admin.championships.show', $championship) }}"
                                           class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="{{ route('admin.championships.edit', $championship) }}"
                                           class="btn btn-sm btn-warning">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button type="button" class="btn btn-sm btn-danger"
                                                onclick="confirmDelete({{ $championship->id }})">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                        <form id="delete-form-{{ $championship->id }}"
                                              action="{{ route('admin.championships.destroy', $championship) }}"
                                              method="POST" class="d-none">
                                            @csrf
                                            @method('DELETE')
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="text-center">Nenhum campeonato encontrado.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="mt-4">
        {{ $championships->links() }}
    </div>
</div>

@push('scripts')
<script>
function confirmDelete(id) {
    if (confirm('Tem certeza que deseja excluir este campeonato?')) {
        document.getElementById('delete-form-' + id).submit();
    }
}
</script>
@endpush
@endsection
