@extends('layouts.admin')

@section('content')
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3">Relatórios</h1>
        <div class="btn-group">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                <i class="fas fa-download me-2"></i>Exportar Relatório
            </button>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#" onclick="showExportModal('users')">Usuários</a></li>
                <li><a class="dropdown-item" href="#" onclick="showExportModal('championships')">Campeonatos</a></li>
                <li><a class="dropdown-item" href="#" onclick="showExportModal('contents')">Conteúdos</a></li>
                <li><a class="dropdown-item" href="#" onclick="showExportModal('transactions')">Transações</a></li>
            </ul>
        </div>
    </div>

    <!-- Cards de Estatísticas -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title">Total de Usuários</h6>
                            <h2 class="mb-0">{{ $stats['total_users'] }}</h2>
                        </div>
                        <i class="fas fa-users fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title">Total de Campeonatos</h6>
                            <h2 class="mb-0">{{ $stats['total_championships'] }}</h2>
                        </div>
                        <i class="fas fa-trophy fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title">Total de Conteúdos</h6>
                            <h2 class="mb-0">{{ $stats['total_contents'] }}</h2>
                        </div>
                        <i class="fas fa-image fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title">Receita Total</h6>
                            <h2 class="mb-0">R$ {{ number_format($stats['total_revenue'], 2, ',', '.') }}</h2>
                        </div>
                        <i class="fas fa-dollar-sign fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Gráficos -->
    <div class="row mb-4">
        <!-- Usuários por Mês -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Novos Usuários por Mês</h5>
                </div>
                <div class="card-body">
                    <canvas id="usersChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Receita por Mês -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Receita por Mês</h5>
                </div>
                <div class="card-body">
                    <canvas id="revenueChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Conteúdos por Status -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Conteúdos por Status</h5>
                </div>
                <div class="card-body">
                    <canvas id="contentStatusChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Campeonatos Mais Populares -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Campeonatos Mais Populares</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Campeonato</th>
                                    <th>Participantes</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($popularChampionships as $championship)
                                    <tr>
                                        <td>{{ $championship->name }}</td>
                                        <td>{{ $championship->contents_count }}</td>
                                        <td>
                                            <span class="badge bg-{{ $championship->status === 'active' ? 'success' : 'danger' }}">
                                                {{ $championship->status }}
                                            </span>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal de Exportação -->
<div class="modal fade" id="exportModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Exportar Relatório</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="export-form" action="" method="GET">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="start_date" class="form-label">Data Inicial</label>
                        <input type="date" class="form-control" id="start_date" name="start_date" required>
                    </div>
                    <div class="mb-3">
                        <label for="end_date" class="form-label">Data Final</label>
                        <input type="date" class="form-control" id="end_date" name="end_date" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Exportar</button>
                </div>
            </form>
        </div>
    </div>
</div>

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Configuração dos gráficos
const usersData = @json($usersPerMonth);
const revenueData = @json($revenuePerMonth);
const contentStatusData = @json($contentsByStatus);

// Gráfico de Usuários
new Chart(document.getElementById('usersChart'), {
    type: 'line',
    data: {
        labels: usersData.map(item => item.month),
        datasets: [{
            label: 'Novos Usuários',
            data: usersData.map(item => item.count),
            borderColor: 'rgb(75, 192, 192)',
            tension: 0.1
        }]
    }
});

// Gráfico de Receita
new Chart(document.getElementById('revenueChart'), {
    type: 'bar',
    data: {
        labels: revenueData.map(item => item.month),
        datasets: [{
            label: 'Receita (R$)',
            data: revenueData.map(item => item.total),
            backgroundColor: 'rgb(54, 162, 235)'
        }]
    }
});

// Gráfico de Status dos Conteúdos
new Chart(document.getElementById('contentStatusChart'), {
    type: 'doughnut',
    data: {
        labels: contentStatusData.map(item => item.status),
        datasets: [{
            data: contentStatusData.map(item => item.count),
            backgroundColor: [
                'rgb(255, 99, 132)',
                'rgb(75, 192, 192)',
                'rgb(255, 205, 86)'
            ]
        }]
    }
});

function showExportModal(type) {
    const modal = new bootstrap.Modal(document.getElementById('exportModal'));
    document.getElementById('export-form').action = `/admin/reports/export/${type}`;
    modal.show();
}
</script>
@endpush
@endsection
