<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="theme-color" content="#4a90e2">

    <title><?php echo e(config('app.name', 'Laravel')); ?> - Admin</title>

    <!-- PWA -->
    <link rel="manifest" href="/manifest.json">
    <link rel="apple-touch-icon" href="/images/icons/icon-192x192.png">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="/css/admin.css" rel="stylesheet">

    <style>
        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 48px 0 0;
            box-shadow: inset -1px 0 0 rgba(0, 0, 0, .1);
            background-color: #343a40;
            width: 250px;
        }

        .sidebar .nav-link {
            color: #fff;
            padding: .75rem 1.25rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .sidebar .nav-link:hover {
            background-color: rgba(255,255,255,.1);
        }

        .sidebar .nav-link.active {
            background-color: rgba(255,255,255,.2);
        }

        /* Main content */
        .main-content {
            margin-left: 250px;
            padding: 48px 30px;
        }

        /* Navbar */
        .navbar {
            position: fixed;
            top: 0;
            right: 0;
            left: 250px;
            z-index: 99;
            height: 48px;
            padding: 0 30px;
            background-color: #fff;
            box-shadow: 0 1px 3px rgba(0,0,0,.1);
        }

        /* Cards */
        .stats-card {
            transition: transform .2s;
        }
        .stats-card:hover {
            transform: translateY(-5px);
        }

        /* Tables */
        .table th {
            background-color: #f8f9fa;
        }

        /* Forms */
        .form-control:focus, .form-select:focus {
            border-color: #80bdff;
            box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
        }

        /* Buttons */
        .btn-icon {
            padding: .375rem .5rem;
        }

        /* Charts */
        .chart-container {
            position: relative;
            margin: auto;
            height: 300px;
        }
    </style>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <div id="admin-app">
        <!-- Sidebar -->
        <nav class="sidebar">
            <div class="sidebar-sticky">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>"
                           href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="fas fa-tachometer-alt"></i>
                            Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('admin.championships.*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('admin.championships.index')); ?>">
                            <i class="fas fa-trophy"></i>
                            Campeonatos
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('admin.users.*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('admin.users.index')); ?>">
                            <i class="fas fa-users"></i>
                            Usuários
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('admin.contents.*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('admin.contents.index')); ?>">
                            <i class="fas fa-image"></i>
                            Conteúdos
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('admin.reports.*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('admin.reports.index')); ?>">
                            <i class="fas fa-chart-bar"></i>
                            Relatórios
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('admin.settings') ? 'active' : ''); ?>"
                           href="<?php echo e(route('admin.settings')); ?>">
                            <i class="fas fa-cog"></i>
                            Configurações
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Navbar -->
        <nav class="navbar">
            <div class="d-flex justify-content-between w-100">
                <div>
                    <h5 class="mb-0"><?php echo e(config('app.name', 'Laravel')); ?> - Admin</h5>
                </div>
                <div class="dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <?php echo e(Auth::user()->name); ?>

                    </a>
                    <div class="dropdown-menu dropdown-menu-end">
                        <a class="dropdown-item" href="<?php echo e(route('admin.settings')); ?>">
                            <i class="fas fa-cog me-2"></i>Configurações
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                            <i class="fas fa-sign-out-alt me-2"></i><?php echo e(__('Logout')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="main-content">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
        // Registrar Service Worker
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('/sw.js')
                    .then(registration => {
                        console.log('ServiceWorker registrado com sucesso:', registration.scope);
                    })
                    .catch(error => {
                        console.log('Falha ao registrar ServiceWorker:', error);
                    });
            });
        }
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\digital\resources\views/layouts/admin.blade.php ENDPATH**/ ?>