<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white stats-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title">Usuários</h6>
                            <h2 class="mb-0"><?php echo e($stats['users_count']); ?></h2>
                        </div>
                        <i class="fas fa-users fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white stats-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title">Campeonatos Ativos</h6>
                            <h2 class="mb-0"><?php echo e($stats['active_championships']); ?></h2>
                        </div>
                        <i class="fas fa-trophy fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white stats-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title">Conteúdos Pendentes</h6>
                            <h2 class="mb-0"><?php echo e($stats['pending_contents']); ?></h2>
                        </div>
                        <i class="fas fa-image fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white stats-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title">Receita Total</h6>
                            <h2 class="mb-0">R$ <?php echo e(number_format($stats['revenue'], 2, ',', '.')); ?></h2>
                        </div>
                        <i class="fas fa-dollar-sign fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Campeonatos Ativos e Top Competidores -->
    <div class="row mb-4">
        <!-- Campeonatos Ativos -->
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Campeonatos Ativos</h5>
                    <a href="<?php echo e(route('admin.championships.create')); ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus me-1"></i>Novo Campeonato
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Nome</th>
                                    <th>Participantes</th>
                                    <th>Prêmio</th>
                                    <th>Término</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $activeChampionships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $championship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($championship->name); ?></td>
                                        <td><?php echo e($championship->contents_count); ?></td>
                                        <td>R$ <?php echo e(number_format($championship->prize, 2, ',', '.')); ?></td>
                                        <td><?php echo e($championship->end_date->format('d/m/Y')); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.championships.show', $championship)); ?>"
                                               class="btn btn-sm btn-info">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center">Nenhum campeonato ativo.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Top Competidores -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0">Top Competidores</h5>
                </div>
                <div class="card-body">
                    <div class="list-group list-group-flush">
                        <?php $__currentLoopData = $topCompetitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-0"><?php echo e($competitor->name); ?></h6>
                                        <small class="text-muted"><?php echo e($competitor->email); ?></small>
                                    </div>
                                    <span class="badge bg-primary rounded-pill">
                                        <?php echo e($competitor->contents_count); ?> conteúdos
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Últimas Atividades -->
    <div class="row">
        <!-- Últimos Conteúdos -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0">Últimos Conteúdos</h5>
                </div>
                <div class="card-body">
                    <div class="list-group list-group-flush">
                        <?php $__currentLoopData = $latestContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-0"><?php echo e($content->title); ?></h6>
                                        <small class="text-muted">
                                            por <?php echo e($content->user->name); ?> em <?php echo e($content->championship->name); ?>

                                        </small>
                                    </div>
                                    <span class="badge bg-<?php echo e($content->status === 'pending' ? 'warning' : 'success'); ?>">
                                        <?php echo e($content->status); ?>

                                    </span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Últimos Usuários -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0">Últimos Usuários</h5>
                </div>
                <div class="card-body">
                    <div class="list-group list-group-flush">
                        <?php $__currentLoopData = $latestUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-0"><?php echo e($user->name); ?></h6>
                                        <small class="text-muted"><?php echo e($user->email); ?></small>
                                    </div>
                                    <small class="text-muted">
                                        <?php echo e($user->created_at->format('d/m/Y H:i')); ?>

                                    </small>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\digital\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>