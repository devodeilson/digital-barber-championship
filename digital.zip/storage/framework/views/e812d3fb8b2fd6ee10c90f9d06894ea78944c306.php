<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3">Conteúdos</h1>
        <div class="btn-group">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                <i class="fas fa-filter me-2"></i>Filtrar por Status
            </button>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?php echo e(route('admin.contents.index')); ?>">Todos</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('admin.contents.index', ['status' => 'pending'])); ?>">Pendentes</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('admin.contents.index', ['status' => 'approved'])); ?>">Aprovados</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('admin.contents.index', ['status' => 'rejected'])); ?>">Rejeitados</a></li>
            </ul>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <!-- Filtros -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <form action="<?php echo e(route('admin.contents.index')); ?>" method="GET" class="d-flex gap-2">
                        <input type="text" name="search" class="form-control"
                               placeholder="Buscar por título" value="<?php echo e(request('search')); ?>">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-search"></i>
                        </button>
                    </form>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Imagem</th>
                            <th>Título</th>
                            <th>Usuário</th>
                            <th>Campeonato</th>
                            <th>Status</th>
                            <th>Data</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <?php if($content->image): ?>
                                        <img src="<?php echo e(Storage::url($content->image)); ?>"
                                             alt="Thumbnail" class="img-thumbnail"
                                             style="width: 50px; height: 50px; object-fit: cover;">
                                    <?php else: ?>
                                        <div class="bg-secondary text-white d-flex align-items-center justify-content-center"
                                             style="width: 50px; height: 50px;">
                                            <i class="fas fa-image"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($content->title); ?></td>
                                <td><?php echo e($content->user->name); ?></td>
                                <td><?php echo e($content->championship->name); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo e($content->status === 'approved' ? 'success' :
                                        ($content->status === 'rejected' ? 'danger' : 'warning')); ?>">
                                        <?php echo e(ucfirst($content->status)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($content->created_at->format('d/m/Y H:i')); ?></td>
                                <td>
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('admin.contents.show', $content)); ?>"
                                           class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <?php if($content->status === 'pending'): ?>
                                            <button type="button" class="btn btn-sm btn-success"
                                                    onclick="approveContent(<?php echo e($content->id); ?>)">
                                                <i class="fas fa-check"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger"
                                                    onclick="showRejectModal(<?php echo e($content->id); ?>)">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        <?php endif; ?>
                                        <button type="button" class="btn btn-sm btn-danger"
                                                onclick="confirmDelete(<?php echo e($content->id); ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                    <form id="approve-form-<?php echo e($content->id); ?>"
                                          action="<?php echo e(route('admin.contents.approve', $content)); ?>"
                                          method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                    </form>
                                    <form id="delete-form-<?php echo e($content->id); ?>"
                                          action="<?php echo e(route('admin.contents.destroy', $content)); ?>"
                                          method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center">Nenhum conteúdo encontrado.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="mt-4">
        <?php echo e($contents->links()); ?>

    </div>
</div>

<!-- Modal de Rejeição -->
<div class="modal fade" id="rejectModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Rejeitar Conteúdo</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="reject-form" action="" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="feedback" class="form-label">Feedback</label>
                        <textarea class="form-control" id="feedback" name="feedback" rows="3" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-danger">Rejeitar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function approveContent(id) {
    if (confirm('Tem certeza que deseja aprovar este conteúdo?')) {
        document.getElementById('approve-form-' + id).submit();
    }
}

function confirmDelete(id) {
    if (confirm('Tem certeza que deseja excluir este conteúdo?')) {
        document.getElementById('delete-form-' + id).submit();
    }
}

function showRejectModal(id) {
    const modal = new bootstrap.Modal(document.getElementById('rejectModal'));
    document.getElementById('reject-form').action = `/admin/contents/${id}/reject`;
    modal.show();
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\digital\resources\views/admin/contents/index.blade.php ENDPATH**/ ?>