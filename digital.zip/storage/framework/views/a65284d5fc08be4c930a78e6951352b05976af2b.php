<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3">Campeonatos</h1>
        <a href="<?php echo e(route('admin.championships.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>Novo Campeonato
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Categoria</th>
                            <th>Início</th>
                            <th>Término</th>
                            <th>Prêmio</th>
                            <th>Participantes</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $championships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $championship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($championship->name); ?></td>
                                <td><?php echo e($championship->category); ?></td>
                                <td><?php echo e($championship->start_date->format('d/m/Y')); ?></td>
                                <td><?php echo e($championship->end_date->format('d/m/Y')); ?></td>
                                <td>R$ <?php echo e(number_format($championship->prize, 2, ',', '.')); ?></td>
                                <td><?php echo e($championship->contents_count); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo e($championship->status === 'active' ? 'success' : 'danger'); ?>">
                                        <?php echo e($championship->status); ?>

                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('admin.championships.show', $championship)); ?>"
                                           class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.championships.edit', $championship)); ?>"
                                           class="btn btn-sm btn-warning">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button type="button" class="btn btn-sm btn-danger"
                                                onclick="confirmDelete(<?php echo e($championship->id); ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                        <form id="delete-form-<?php echo e($championship->id); ?>"
                                              action="<?php echo e(route('admin.championships.destroy', $championship)); ?>"
                                              method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center">Nenhum campeonato encontrado.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="mt-4">
        <?php echo e($championships->links()); ?>

    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function confirmDelete(id) {
    if (confirm('Tem certeza que deseja excluir este campeonato?')) {
        document.getElementById('delete-form-' + id).submit();
    }
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\digital\resources\views/admin/championships/index.blade.php ENDPATH**/ ?>